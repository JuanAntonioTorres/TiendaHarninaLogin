create procedure comprobarLogin(IN usuario_in varchar(7), IN password_in varchar(30), OUT retorno tinyint(1))
  BEGIN
DECLARE userTemp varchar(7) DEFAULT "";
DECLARE passwordTemp varchar(30) DEFAULT "";

	SELECT login_cliente.usuario,login_cliente.password INTO userTemp , passwordTemp FROM login_cliente WHERE login_cliente.usuario = usuario_in AND login_cliente.password() = md5(password_in);

	SET retorno = ((userTemp <> "") AND (passwordTemp<>""));
    
END;

